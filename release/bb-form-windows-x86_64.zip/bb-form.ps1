$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
& bb "$ScriptDir\bb-form.clj" @args

