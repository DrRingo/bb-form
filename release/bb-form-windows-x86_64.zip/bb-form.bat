@echo off
setlocal EnableDelayedExpansion
set "SCRIPT_DIR=%~dp0"
bb "%SCRIPT_DIR%bb-form.clj" %*
